public class HitungGaji {

    // Method untuk menghitung gaji karyawan
    private int perhitunganGaji(int jamKerja, int gajiPerJam) {
        if (jamKerja < 0 || gajiPerJam < 0) {
            System.out.println("Jam kerja dan gaji per jam harus bernilai positif.");
            return 0;
        }
        return jamKerja * gajiPerJam;
    }

    public static void main(String[] args) {
        HitungGaji hitung = new HitungGaji();

        int gajiTotal = hitung.perhitunganGaji(40, 250000);
        System.out.println("Gaji karyawan dengan 40 jam kerja = " + gajiTotal);
    }
}